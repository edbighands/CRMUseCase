package com.alti.sb;

import javax.ejb.Local;

import com.alti.TO.CaseMessage;

@Local
public interface SG1CUTriggerBeanLocal {

	
	public void sendCreateTrigger(String caseDetailsMsg);
}
