package com.alti.sb;

import java.io.StringReader;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import com.alti.TO.CaseMessage;

/**
 * Session Bean implementation class SG1CUTriggerBean
 */
@Stateless(mappedName = "SG1CUTriggerBean")
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
public class SG1CUTriggerBean implements SG1CUTriggerBeanLocal {

    /**
     * Default constructor. 
     */
    public SG1CUTriggerBean() {
        // TODO Auto-generated constructor stub
    }
    
    private JAXBContext jc;
    private Unmarshaller unmarshaller;
    @PostConstruct
    public void initilial()
    {
    	 try {
			 jc = JAXBContext.newInstance(CaseMessage.class);
			 unmarshaller  = jc.createUnmarshaller();
		        unmarshaller.setProperty("eclipselink.media-type", "application/json");
		        unmarshaller.setProperty("eclipselink.json.include-root", false);
		        client   = ClientBuilder.newClient();
		        webTarget=  client.target(REST_URI);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException("MOXY INIT Context Failed");
		}
    }
    
    private static final String REST_URI = "http://localhost:7080/SG1OfferingDBDataService/SG1/rest/cases/create";
    private Client client ;
    private WebTarget webTarget ;

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public void sendCreateTrigger(String caseDetailsMsg) {
		StringReader reader;
	    try {
	    	
	    	   reader = new StringReader(caseDetailsMsg);
	    	    JAXBElement<CaseMessage> jaxbElement = unmarshaller.unmarshal(new StreamSource(reader), CaseMessage.class);
	    	 CaseMessage caseDetails=   jaxbElement.getValue();
	    	 Response res=    webTarget.request(MediaType.APPLICATION_JSON).put(Entity.entity(caseDetails, MediaType.APPLICATION_JSON));
	    	 System.out.println("FROM SESS BEAN "+res.getStatus());
	    	    
		
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException("Could not convert JMS Message to JSON");
		}
		
	}

    
    
}
