package com.alti.TO;

import java.util.Date;

import com.alti.models.CaseStatus;

public class CaseMessage {

	private String CaseID;
	private Date EntryCUDate;
	private String CaseDescription;
	private CaseStatus statusOfCase;
	
	public String getCaseID() {
		return CaseID;
	}
	public void setCaseID(String caseID) {
		CaseID = caseID;
	}
	public Date getEntryCUDate() {
		return EntryCUDate;
	}
	public void setEntryCUDate(Date entryCUDate) {
		EntryCUDate = entryCUDate;
	}
	public String getCaseDescription() {
		return CaseDescription;
	}
	public void setCaseDescription(String caseDescription) {
		CaseDescription = caseDescription;
	}
	public CaseStatus getStatusOfCase() {
		return statusOfCase;
	}
	public void setStatusOfCase(CaseStatus statusOfCase) {
		this.statusOfCase = statusOfCase;
	}
	public CaseMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
