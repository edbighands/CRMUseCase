package com.alti.mdb;

import java.io.StringReader;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.ejb.MessageDrivenContext;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import com.alti.TO.CaseMessage;
import com.alti.sb.SG1CUTriggerBeanLocal;

/**
 * Message-Driven Bean implementation class for: SG1MDB
 */
@MessageDriven(
		activationConfig = { @ActivationConfigProperty(
				propertyName = "destination", propertyValue = "crm/casesQ"), @ActivationConfigProperty(
				propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
				 @ActivationConfigProperty(propertyName = "messageSelector",propertyValue = "appName = 'SG1'")
		}, 
		mappedName = "crm/casesQ")
@TransactionManagement(TransactionManagementType.CONTAINER)
public class SG1MDB implements MessageListener {

    /**
     * Default constructor. 
     */
    public SG1MDB() {
        // TODO Auto-generated constructor stub
    }
    
    @Resource
  private MessageDrivenContext messageDrivenContext;
   
	
    @EJB
    private SG1CUTriggerBeanLocal sG1CUTriggerBeanLocal;
    
 
	/**
     * @see MessageListener#onMessage(Message)
     */
    @TransactionAttribute(TransactionAttributeType.MANDATORY)
    public void onMessage(Message message) {
        // TODO Auto-generated method stub
    	String txtMsg="";
    	
    try {
    	txtMsg	=	((TextMessage)message).getText();
    	   
    	sG1CUTriggerBeanLocal.sendCreateTrigger(txtMsg);
    	    
	} catch (JMSException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
		messageDrivenContext.setRollbackOnly();
	} 
    catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
		messageDrivenContext.setRollbackOnly();
	} 
    
    
    
    }

}
