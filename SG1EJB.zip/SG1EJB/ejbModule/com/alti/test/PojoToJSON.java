package com.alti.test;

import java.io.StringWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.alti.TO.CaseMessage;
import com.alti.models.CaseStatus;

public class PojoToJSON {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		 CaseMessage caseDetails = new  CaseMessage();
		 caseDetails.setCaseID("T1");
		 caseDetails.setCaseDescription("Test 1");
		 caseDetails.setStatusOfCase(CaseStatus.OPEN);
		 caseDetails.setEntryCUDate(new Date());
		StringWriter sw= new StringWriter();
		
		 Map<String, Object> properties = new HashMap<String, Object>(1);
	      properties.put("eclipselink.media-type", "application/json");
	      JAXBContext jc = JAXBContext.newInstance(new Class[] { CaseMessage.class }, properties);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(caseDetails, sw);
		System.out.println(sw.toString());
	}

}
