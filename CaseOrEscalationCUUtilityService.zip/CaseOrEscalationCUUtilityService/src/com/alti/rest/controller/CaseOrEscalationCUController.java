package com.alti.rest.controller;

import java.util.ArrayList;
import java.util.Date;

import java.util.List;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import com.alti.TO.CaseMessage;
import com.alti.jms.service.SpringJmsProducer;


/**
 * Handles requests for the Employee service.
 */
@Controller
@RequestMapping("/rest")
public class CaseOrEscalationCUController {
	

	
	@Autowired
	private SpringJmsProducer springJmsProducer;

	
	@RequestMapping(value = "/createCase/{appName}", method = RequestMethod.PUT,consumes="application/json",produces="application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public @ResponseBody String createCase(@RequestBody CaseMessage caseMessage, @PathVariable String appName) {
		
		springJmsProducer.sendMessage(caseMessage,appName);
		
		return "OK";
	}
	
	

	
	@RequestMapping(value = "/createEscalation/{appName}", method = RequestMethod.PUT,consumes="application/json",produces="application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public @ResponseBody String createEscalation(@RequestBody CaseMessage caseMessage,@PathVariable String appName) {
		
		//springJmsProducerEscalation.sendMessage(caseMessage,appName);
		
		return "OK";
	}

	
}
