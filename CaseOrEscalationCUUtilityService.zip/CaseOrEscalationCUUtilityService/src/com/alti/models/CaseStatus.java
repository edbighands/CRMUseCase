package com.alti.models;

public enum CaseStatus {

	
	OPEN,RESTORED,CLOSED
	
}
