package com.alti.models;

import java.io.Serializable;
import java.lang.String;
import java.util.Date;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: SG1CaseEntity
 *
 */
@Entity
@NamedQueries({

@NamedQuery(name="SG1CaseEntity.findAll", query="SELECT s FROM SG1CaseEntity s") ,
@NamedQuery(name="SG1CaseEntity.findByCaseID", query="SELECT s FROM SG1CaseEntity s WHERE s.casePK.caseID = :caseID ORDER BY  s.casePK.entryCUDate DESC"),
@NamedQuery(name="SG1CaseEntity.findAllOrderByLatest", query="SELECT s FROM SG1CaseEntity s ORDER BY s.casePK.entryCUDate DESC")

})
public class SG1CaseEntity implements Serializable {

	   
	@EmbeddedId
	private SG1CaseEntityPK casePK;
	private String CaseDescription;
	@Enumerated(EnumType.STRING)
	private CaseStatus statusOfCase;
	
	private static final long serialVersionUID = 1L;

	public SG1CaseEntity() {
		super();
	}   
	   
	public String getCaseDescription() {
		return this.CaseDescription;
	}

	public void setCaseDescription(String CaseDescription) {
		this.CaseDescription = CaseDescription;
	}

	public SG1CaseEntityPK getCasePK() {
		return casePK;
	}
	public String getCasePKGetCaseID() {
		return casePK.getCaseID();
	}
	public Date getCasePKGetCaseCUDate() {
		return casePK.getEntryCUDate();
	}
	
	public void setCasePK(SG1CaseEntityPK casePK) {
		this.casePK = casePK;
	}

	public CaseStatus getStatusOfCase() {
		return statusOfCase;
	}

	public void setStatusOfCase(CaseStatus statusOfCase) {
		this.statusOfCase = statusOfCase;
	}   
	
   
}
