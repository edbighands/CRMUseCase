package com.alti.models;

import java.io.Serializable;
import java.lang.String;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Embeddable;

@Embeddable
public class SG1CaseEntityPK  implements Serializable {   
   
	         
	private String caseID;
	private Date entryCUDate;
	private static final long serialVersionUID = 1L;

	public SG1CaseEntityPK() {}

	public String getCaseID() {
		return caseID;
	}

	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}

	public Date getEntryCUDate() {
		return entryCUDate;
	}

	public void setEntryCUDate(Date entryCUDate) {
		this.entryCUDate = entryCUDate;
	}

	@Override
	public int hashCode() {
		return Objects.hash(caseID, entryCUDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SG1CaseEntityPK)) {
			return false;
		}
		SG1CaseEntityPK other = (SG1CaseEntityPK) obj;
		return Objects.equals(caseID, other.caseID) && Objects.equals(entryCUDate, other.entryCUDate);
	}

	
	

}
