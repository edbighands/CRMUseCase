package com.alti.utils;

import com.alti.TO.CaseMessage;
import com.alti.models.SG1CaseEntity;
import com.alti.models.SG1CaseEntityPK;

public class DTOtoModelMapper {

	
	
	public static SG1CaseEntity  mapDTOToModel(CaseMessage caseMessageDTO, SG1CaseEntity caseModel ) {
		
		
		  final SG1CaseEntityPK caseEntityPK = new SG1CaseEntityPK();
	        caseEntityPK.setCaseID(caseMessageDTO.getCaseID());
	        caseEntityPK.setEntryCUDate(caseMessageDTO.getEntryCUDate());
	        
	        caseModel.setCaseDescription(caseMessageDTO.getCaseDescription());
	        caseModel.setCasePK(caseEntityPK);
		  return caseModel;
	}
	
	
	public static CaseMessage mapModelToDTO(SG1CaseEntity caseModel,CaseMessage caseMessageDTO) {
		
		  
		  caseMessageDTO.setCaseID(caseModel.getCasePKGetCaseID());
		  caseMessageDTO.setCaseDescription(caseModel.getCaseDescription());
		  caseMessageDTO.setEntryCUDate(caseModel.getCasePKGetCaseCUDate());
		  return caseMessageDTO;
	}
	
}
