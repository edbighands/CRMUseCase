package com.alti.DAL;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import com.alti.TO.CaseMessage;
import com.alti.dao.SG1DAO;

/**
 * Session Bean implementation class DAOAccessLayer
 */
@Stateless(mappedName = "DAOAccessLayer")
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
public class DAOAccessLayer implements DAOAccessLayerLocal {

    /**
     * Default constructor. 
     */
    public DAOAccessLayer() {
        // TODO Auto-generated constructor stub
    }

    
    @Resource
    private SessionContext sctx;
    
    @EJB
	private SG1DAO sG1DAO;
    
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void initiateCreateCaseSequences(CaseMessage caseDetails)
    {
    	try {
    		//any preparatory calls in same transaction
    		//API calls to salesforce if any
    	
    	sG1DAO.save(caseDetails);
    	//any other DAO calls if needed
    	//any other cleanup stages to salesforce EJBs
    	}catch(Exception e)
    	{
    		sctx.setRollbackOnly();
    		//explicit rollback and rethrow
    		throw new RuntimeException("Exception in DB Data Service Access Layer "+e.getLocalizedMessage()+e.getMessage()+e.getCause().getLocalizedMessage());
    		
    	}
    	
    	
    }
    
    
    //no global transaction needed
    public List<CaseMessage> extractAllCases()
    {
    	
    	
    	
    return	sG1DAO.findAllLatestFirst();
    	
    	
    	
    	
    }
    
  //no global transaction needed
    public CaseMessage extractParticularCaseByID(String caseID)
    {
    	
    	
    	
    return	sG1DAO.findByID(caseID);
    	
    	
    	
    	
    }
    
}
