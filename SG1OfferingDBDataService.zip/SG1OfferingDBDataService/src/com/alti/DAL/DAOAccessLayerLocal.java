package com.alti.DAL;

import java.util.List;

import javax.ejb.Local;

import com.alti.TO.CaseMessage;

@Local
public interface DAOAccessLayerLocal {

	public void initiateCreateCaseSequences(CaseMessage caseDetails);
	  public List<CaseMessage> extractAllCases();
	  public CaseMessage extractParticularCaseByID(String caseID);
}
