package com.alti.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;

import com.alti.DAL.DAOAccessLayer;
import com.alti.DAL.DAOAccessLayerLocal;
import com.alti.TO.CaseMessage;


@Path("/cases")

@ManagedBean
@Named

public class SG1DBDataService {

	

	public SG1DBDataService() {
		// TODO Auto-generated constructor stub
	}
	
	@Inject

	private DAOAccessLayerLocal dAOAccessLayer;
	
	 @PUT
	    @Path("/create")
	 @Produces("text/plain")
	 @Consumes("application/json")
	    public Response create( final CaseMessage caseDetails) {
		String msg="OK";
		 try {
		 dAOAccessLayer.initiateCreateCaseSequences(caseDetails); 
		 }
		 catch(Exception e)
		 {e.printStackTrace();
			 msg=e.getMessage();
			 return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(msg).build();
		 }
		 
		 return Response.status(Response.Status.CREATED).entity(msg).build();
		
		 
	    
	 }
	 
	 
	 
	 
	 
	 
	    @GET
	    @Path("/all")
	    @Produces("application/json")
		 
	    public List<CaseMessage> extractAll() {
	    	String msg="OK";
	    	 List<CaseMessage> lResult= new ArrayList<>();
	    	 GenericEntity<List<CaseMessage>> entity;
			 try {
				 lResult=	 dAOAccessLayer.extractAllCases();
				 entity = new GenericEntity<List<CaseMessage>>(lResult) {};
			 }
			 catch(Exception e)
			 {e.printStackTrace();
				 msg=e.getMessage();
				// return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(msg).build();
			 }
			 
			// return Response.ok(entity).build();
			 return lResult;
	    }
	    
	    
	    
	    
	    @GET
	    @Path("/specific/{caseID}")
	    @Produces("application/json")
		
	    public Response extractSpecific(@PathParam("caseID") final String caseID) {
	    	String msg="OK";
	    	 CaseMessage lResult;
			 try {
				 lResult	=	 dAOAccessLayer.extractParticularCaseByID(caseID);
			 }
			 catch(Exception e)
			 {e.printStackTrace();
				 msg=e.getMessage();
				 return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(msg).build();
			 }
			 
			 return Response.status(Response.Status.OK).entity(lResult).build();
	    }
	
	
}
