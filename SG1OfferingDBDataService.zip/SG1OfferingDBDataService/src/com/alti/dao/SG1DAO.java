package com.alti.dao;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Lock;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.alti.TO.CaseMessage;
import com.alti.models.SG1CaseEntity;
import com.alti.models.SG1CaseEntityPK;
import com.alti.utils.DTOtoModelMapper;

import javax.ejb.LockType;

@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@Singleton
@Lock(LockType.READ)
@TransactionManagement(TransactionManagementType.CONTAINER)

public class SG1DAO {

	 @PersistenceContext
	    private EntityManager em;
	 
	 
	 @TransactionAttribute(TransactionAttributeType.MANDATORY)

	    public void save(final CaseMessage caseMessageDTO) {
	        final SG1CaseEntity caseModel = new SG1CaseEntity();
	        
	        DTOtoModelMapper.mapDTOToModel(caseMessageDTO,caseModel);
	        
	        em.persist(caseModel);
	        
	    }

	    public List<CaseMessage> findAll() {
	    	Query query =
	    		      em.createNamedQuery("SG1CaseEntity.findAll");
	    		  List results = query.getResultList();
	    		  List<CaseMessage> caseList = new ArrayList<>();
	    		  for(Object o : results)
	    		  {
	    			  SG1CaseEntity caseModel = (SG1CaseEntity) o;
	    			  CaseMessage caseMessageDTO = new CaseMessage();
	    			  DTOtoModelMapper.mapModelToDTO(caseModel, caseMessageDTO);
	    			  caseList.add(caseMessageDTO);
	    		  }
	    		  
	    		  
	    	return 	caseList;  
	    }
	    
	    
	    
	    
	    
	    public CaseMessage findByID(String caseID) {
	    	
	    	Query query =
	    		      em.createNamedQuery("SG1CaseEntity.findByCaseID");
	    	SG1CaseEntity caseModel = (SG1CaseEntity) query.getResultList().get(0);
	    	 CaseMessage caseMessageDTO = new CaseMessage();
	    	 DTOtoModelMapper.mapModelToDTO(caseModel, caseMessageDTO);
	    		
	    	 return caseMessageDTO;
	    	
	    }
	    
	    
	    
	    public List<CaseMessage> findAllLatestFirst() {
	    	Query query =
	    		      em.createNamedQuery("SG1CaseEntity.findAllOrderByLatest");
	    		  List results = query.getResultList();
	    		  List<CaseMessage> caseList = new ArrayList<>();
	    		  for(Object o : results)
	    		  {
	    			  SG1CaseEntity caseModel = (SG1CaseEntity) o;
	    			  CaseMessage caseMessageDTO = new CaseMessage();
	    			  DTOtoModelMapper.mapModelToDTO(caseModel, caseMessageDTO);
	    			  caseList.add(caseMessageDTO);
	    		  }
	    		  
	    		  
	    	return 	caseList;  
	    }  
	    
	    
	    
	
	
}
